package VerifInfo.BG;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.io.*;

public class verifInfoMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	System.out.println("Iniciando verificacion de datos");
	System.out.println("ID SOA a verificar: " + args [0]);
    String targetURL = "http://ecc.bancogalicia.com.ar/sites/ac/soa/_api/web/lists/getbytitle('Operaciones%20Corporativas')/items(1711)";
    System.out.println (targetURL);
    try {
    		FileWriter fichero = null;
    		PrintWriter pw = null;
    		fichero = new FileWriter("C:\\Users\\l0646482\\n\\mi_desa\\Eclipse\\cws\\OperacionesCorporativas1711.xml");
    		pw = new PrintWriter(fichero);
    		URL restServiceURL = new URL(targetURL);
    		HttpURLConnection httpConnection = (HttpURLConnection) restServiceURL.openConnection();
    		httpConnection.setRequestMethod("GET");
    		httpConnection.setRequestProperty("Accept", "application/json");
    		if (httpConnection.getResponseCode() != 200) {
    			throw new RuntimeException("HTTP GET Request Failed with Error code : "+ httpConnection.getResponseCode());
    		}
    		BufferedReader responseBuffer = new BufferedReader(new InputStreamReader((httpConnection.getInputStream())));
    		String output;
    		while ((output = responseBuffer.readLine()) != null) {
//              System.out.println(output);
    			pw.println(output);
    		}
    		fichero.close();
    		httpConnection.disconnect();
        } 
        catch (MalformedURLException e) {
        	e.printStackTrace();
        } 
        catch (IOException e) {
        	e.printStackTrace();
        }

    System.out.println ("Analizando XML");
    
	}
	
	

}
